<?php ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title>Errors in Recording Configuration</title>
<link href="css/coolMenu.css" rel="stylesheet" type="text/css" media="screen"/>
<link rel="stylesheet" type="text/css" href="css/style.css" />
</head>
<body>
<div class="banner">
<img id="bannerLogo" border="0" src="images/home.png" height="50" width="360">
<div id="log" >
<a href="errors.php">Errors</a>
</div>
</div>
<div class="content">

<h3 style="margin: auto;margin-top:20px;text-align: center;">Errors Encountered</h3>


<p style="margin: auto;margin-top:20px;text-align: center;"> The Recordings Server encountered errors and had to shut down. We apologize for the inconvenience.</p>
</div>
</body>
</html>
